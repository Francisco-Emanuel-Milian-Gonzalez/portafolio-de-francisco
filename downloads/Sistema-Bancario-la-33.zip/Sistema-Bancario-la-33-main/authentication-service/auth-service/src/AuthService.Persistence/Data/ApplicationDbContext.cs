using System;
using AuthService.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;

namespace AuthService.Persistence.Data;

public class ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : DbContext(options)
{
    public DbSet<User> Users { get; set; }
    public DbSet<Role> Roles { get; set; }
    public DbSet<UserRole> UserRoles { get; set; }
    public DbSet<UserProfile> UserProfiles { get; set; }
    public DbSet<UserEmail> UserEmails { get; set; }
    public DbSet<UserPasswordReset> UserPasswordResets { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
        //Aplicar snake_case a tablas y columnas
        foreach (var entity in modelBuilder.Model.GetEntityTypes())
        {
            //tablas snake_case
            var tableName = entity.GetTableName();
            if (!string.IsNullOrEmpty(tableName))
            {
                entity.SetTableName(ToSnakeCase(tableName));
            }

            foreach (var property in entity.GetProperties())
            {
                //columnas snake_case
                var columName = property.GetColumnName();
                if (!string.IsNullOrEmpty(columName))
                {
                    property.SetColumnName(ToSnakeCase(columName));
                }
            }

            foreach (var key in entity.GetKeys())
            {
                //foreign keys snake_case
                var keyName = key.GetName();
                if (!string.IsNullOrEmpty(keyName))
                {
                    key.SetName(ToSnakeCase(keyName));
                }
            }

            //indexes snake_case
            foreach (var index in entity.GetIndexes())
            {
                var indexName = index.GetDatabaseName();
                if (!string.IsNullOrEmpty(indexName))
                {
                    index.SetDatabaseName(ToSnakeCase(indexName));
                }
            }
        }

        modelBuilder.Entity<User>(entity =>
        {
            entity.HasKey(e => e.Id);
            entity.Property(e => e.Id)
              .HasMaxLength(16)
              .ValueGeneratedOnAdd();
            entity.Property(e => e.Name)
              .IsRequired()
              .HasMaxLength(25);
            entity.Property(e => e.SurName)
              .IsRequired()
              .HasMaxLength(25);
            entity.Property(e => e.UserName)
              .IsRequired();
            entity.Property(e => e.Email)
              .IsRequired();
            entity.Property(e => e.Password)
              .IsRequired()
              .HasMaxLength(255);
            entity.Property(e => e.Status)
              .HasDefaultValue(false);
            entity.Property(e => e.CreatedAt)
              .IsRequired();
            entity.Property(e => e.UpdatedAt)
              .IsRequired();

            // Configuración de User
            //Indices para optimización de busqueda
            entity.HasIndex(e => e.UserName).IsUnique();
            entity.HasIndex(e => e.Email).IsUnique();

            //Relaciones
            entity.HasOne(e => e.UserProfile)
                .WithOne(p => p.User)
                .HasForeignKey<UserProfile>(p => p.UserId);
            entity.HasMany(e => e.UserRoles)
                .WithOne(ur => ur.User)
                .HasForeignKey(ur => ur.UserId);
            entity.HasOne(e => e.UserEmail)
                .WithOne(ur => ur.User)
                .HasForeignKey<UserEmail>(ue => ue.UserId);
            entity.HasOne(e => e.UserPasswordReset)
                .WithOne(upr => upr.User)
                .HasForeignKey<UserPasswordReset>(upr => upr.UserId);

            // Configuración de UserProfile
            modelBuilder.Entity<UserProfile>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Id)
                    .HasMaxLength(16)
                    .ValueGeneratedOnAdd();
                entity.Property(e => e.UserId)
                    .HasMaxLength(16);
                entity.Property(e => e.ProfilePicture).HasDefaultValue("");
                entity.Property(e => e.Phone).HasMaxLength(8);
                entity.Property(e => e.Address).HasMaxLength(200).HasDefaultValue("");
                entity.Property(e => e.Job).HasMaxLength(100).HasDefaultValue("");
                entity.Property(e => e.Dpi).HasMaxLength(13).HasDefaultValue("");
                entity.Property(e => e.Income).HasColumnType("decimal(18,2)").HasDefaultValue(0m);
            });

            // Configuración de Role
            modelBuilder.Entity<Role>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Id)
                    .HasMaxLength(16)
                    .ValueGeneratedOnAdd();
                entity.Property(e => e.Name).IsRequired();
                entity.Property(e => e.CreatedAt)
                    .IsRequired();
                entity.Property(e => e.UpdatedAt)
                    .IsRequired();
            });

            // Configuración de UserRole
            modelBuilder.Entity<UserRole>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Id)
                    .HasMaxLength(16)
                    .ValueGeneratedOnAdd();
                entity.Property(e => e.UserId)
                    .HasMaxLength(16);
                entity.Property(e => e.RoleId)
                    .HasMaxLength(16);
                entity.Property(e => e.CreatedAt)
                    .IsRequired();
                entity.Property(e => e.UpdatedAt)
                    .IsRequired();
                entity.HasOne(ur => ur.User)
                    .WithMany(u => u.UserRoles)
                    .HasForeignKey(ur => ur.UserId);
                entity.HasOne(ur => ur.Role)
                    .WithMany(r => r.UserRoles)
                    .HasForeignKey(ur => ur.RoleId);
            });

            // Configuración de UserEmail
            modelBuilder.Entity<UserEmail>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Id)
                    .HasMaxLength(16)
                    .ValueGeneratedOnAdd();
                entity.Property(e => e.UserId)
                    .HasMaxLength(16);
                entity.Property(e => e.EmailVerified).HasDefaultValue(false);
                entity.Property(e => e.EmailVerificationToken).HasMaxLength(256);
            });

            // Configuración de UserPasswordReset
            modelBuilder.Entity<UserPasswordReset>(entity =>
            {
                entity.HasKey(e => e.Id);
                entity.Property(e => e.Id)
                    .HasMaxLength(16)
                    .ValueGeneratedOnAdd();
                entity.Property(e => e.UserId)
                    .HasMaxLength(16);
                entity.Property(e => e.PasswordResetToken).HasMaxLength(256);
            });
        });
    }

    private void UpdateTimestamps()
    {
        var entries = ChangeTracker.Entries()
            .Where(e => (e.Entity is User || e.Entity is Role || e.Entity is UserRole)
                && (e.State == EntityState.Added || e.State == EntityState.Modified));
        
        foreach (var entry in entries)
        {
            if(entry.Entity is User user)
            {
                if (entry.State == EntityState.Added)
                {
                    user.CreatedAt = DateTime.UtcNow;
                }
                user.UpdatedAt = DateTime.UtcNow;
            }
            else if(entry.Entity is Role role)
            {
                if (entry.State == EntityState.Added)
                {
                    role.CreatedAt = DateTime.UtcNow;
                }
                role.UpdatedAt = DateTime.UtcNow;
            }
            else if(entry.Entity is UserRole userRole)
            {
                if (entry.State == EntityState.Added)
                {
                    userRole.CreatedAt = DateTime.UtcNow;
                }
                userRole.UpdatedAt = DateTime.UtcNow;
            }
        }
    }

    private static string ToSnakeCase(string input)
    {
        if (string.IsNullOrEmpty(input)) return input;

        return string.Concat(
            input.Select((c, i) => i > 0 && char.IsUpper(c) ? "_" + c : c.ToString())
        ).ToLower();
    }

    public override int SaveChanges()
    {
        UpdateTimestamps();
        return base.SaveChanges();
    }

    public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        UpdateTimestamps();
        return base.SaveChangesAsync(cancellationToken);
    }
}
